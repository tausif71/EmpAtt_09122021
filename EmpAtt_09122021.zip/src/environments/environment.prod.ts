export const environment = {
  production: true,
  //baseUrl:'http://localhost:59898/',
  baseUrl:'https://giws.saint-gobain.com/EA_API/',
  firebase: {
    apiKey: "AIzaSyAc5UTq8YcCblJFyQzJTl6wrjkVSCsBuEs",
    authDomain: "attendancepwa-e8305.firebaseapp.com",
    projectId: "attendancepwa-e8305",
    storageBucket: "attendancepwa-e8305.appspot.com",
    messagingSenderId: "751666883415",
    appId: "1:751666883415:web:85d36539a916d3d20a6c12",
    measurementId: "G-WDBEL9GXEY"
  }
};
