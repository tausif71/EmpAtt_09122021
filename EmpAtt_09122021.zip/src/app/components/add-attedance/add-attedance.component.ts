import { LocationStrategy } from '@angular/common';
import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {  Router } from '@angular/router';
import { CalendarOptions } from '@fullcalendar/angular';
import { AuthService } from 'src/app/services/auth.service';
import { EmployeeAttendanceService } from 'src/app/services/employee-attendance.service';
import { MasterService } from 'src/app/services/master.service';
declare var $: any;
@Component({
  selector: 'app-add-attedance',
  templateUrl: './add-attedance.component.html',
  styleUrls: ['./add-attedance.component.css']
})
export class AddAttedanceComponent implements OnInit {

  //========================= Variable Declaration Start =========================/
  EmpCount: number = 0;
  AttendanceDataSet = [];
  calendarOptions: CalendarOptions = {}; // fullcalendar Object
  AttendanceForm: FormGroup;
  m_LocationType: string = '';
  LocationList: any = null;
  SelectedDate: string = '';
  todayDateString: string = '';
  outtime: string = '00:00';
  intime: string = '00:00';
  isCheckIn: boolean = true;
  btnText: string = 'Check in';
  PendingAttendanceList = [];
  isPendingAttendance: boolean = true;
  isManagerRemarkPresent: boolean = false;
  _approvalFlag: string = '';
  _attendancemark: string = '';
  // ------------ View Child -------------------------------------------------------
  @ViewChild('updateScreen') updateScreen: ElementRef;
  //========================= Variable Declaration End ===========================/
  constructor(private _empService: EmployeeAttendanceService, private _auth: AuthService,
    private formBuilder: FormBuilder, private _master: MasterService, private _router: Router,
    private locationStrategy: LocationStrategy) {
    this.todayDateString = new Date().toDateString();
this.preventBackButton();
  }

  ModifyRejectClassList(status){
    if(status=='20'){
      return 'reject-attendance'
    }
    else if(status=='15'){
      return 'revise-attendance'
    }
    else{
      return '';
    }
  }
  preventBackButton() {
    history.pushState(null, null, location.href);
    this.locationStrategy.onPopState(() => {
      history.pushState(null, null, location.href);
    })
  }

  // ========== Direct Attendance Form Creation Start ==========================/
  DirectAttendanceForm: FormGroup;
  DirectAttendanceFormCreation() {
    const date = new Date();

    this.DirectAttendanceForm = this.formBuilder.group({
      LocationType: ['', Validators.required],
      AttendanceDate: [date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate()],
      AttendanceStartTime: [this.formatAMPM(new Date)],
      AttendanceEndTime: [''],
      AttendanceRemark: [''],
      AttendanceID: ['0'],
      DayType: ['']
    });
  }
  // ========== Update Attendance Form Creation Start ==========================/
  createForm() {
    this.AttendanceForm = this.formBuilder.group({
      LocationType: ['', Validators.required],
      AttendanceDate: [''],
      AttendanceStartTime: ['', Validators.required],
      AttendanceEndTime: ['', Validators.required],
      AttendanceRemark: [''],
      AttendanceID: ['0'],
      DayType: [''],
      ManagerRemark: ({value: '', disabled: true})
    });
  }
  //======================= Bind All Location Start =================================================/
  GetAllLocation() {
    this._master.GetAllLocation().subscribe((res) => {
      console.log(res);
      if (res.Message == 'Success') {
        //debugger
        if (res._Data != null) {
          if (res._Data.LocationList.length > 0) {
            this.LocationList = res._Data.LocationList;
          }
        } else {
          this.LocationList = null;
        }
      }
      else {
        this.LocationList = null;
      }
    })
  }

  ngOnInit(): void {

    if (localStorage.getItem("empcount")) {
      this.EmpCount = Number(localStorage.getItem("empcount"));
    }
    this.createForm();
    this.DirectAttendanceFormCreation();
    this.GetAllLocation();
    this.PopuplateCalendarAttendance(this._auth.getLoggedInUserid(), '');

    if ((this.intime !== "00:00" && this.intime !== '') && (this.outtime !== "00:00" && this.outtime !== "")) {
      this.isPendingAttendance = true;
    }
  }

  // Populate Calendar With Attendance Status
  PopuplateCalendarAttendance(sgid, id) {

    this._empService.GetEmployeeAttendance1({
      "SGID": sgid,
      "AttendanceID": id
    }).subscribe((res) => {
      if (res.Message == 'Success') {
        if (res._Data != null) {
          console.log(res._Data)
          //debugger
          this.PendingAttendanceList = res._Data.EmpPendingAttendance;
          const CurrentDayAttendance = res._Data.EmpAttendance.filter(a => a.EDA_TodayAttendanceStatus == 'Pending');
          if (CurrentDayAttendance[0] != null && CurrentDayAttendance.length > 0) {
            this.intime = CurrentDayAttendance[0].EDA_InTime == "" ? "00:00" : CurrentDayAttendance[0].EDA_InTime;
            this.outtime = CurrentDayAttendance[0].EDA_OutTime == "" ? "00:00" : CurrentDayAttendance[0].EDA_OutTime;
            if (this.intime !== '00:00' && this.intime != '' && this.intime != '00:00') {
              this.isCheckIn = false;
              this.btnText = "Checkout";
            }
            if ((this.intime != "00:00" && this.intime != "" && this.intime != "00:00") && (this.outtime != "00:00" && this.outtime != "" && this.outtime != "00:00")) {
              //this.isPendingAttendance=true;
            }
            this.DirectAttendanceForm.patchValue({
              "LocationType": CurrentDayAttendance[0].EDA_LT
            });
            this.DirectAttendanceForm.patchValue({
              "SGID": this._auth.getLoggedInUserid(),
              "AttendanceID": CurrentDayAttendance[0].EDA_ID,
              "AttendanceStartTime": CurrentDayAttendance[0].EDA_InTime,
              "AttendanceEndTime": this.outtime,
              "AttendanceEntryType": "Direct",
              "AttendanceRemark": CurrentDayAttendance[0].EDA_Remarks,
              "DayType": CurrentDayAttendance[0].EDA_DT,
              "LocationType": CurrentDayAttendance[0].EDA_LT,
              "AttendanceDate": CurrentDayAttendance[0].EDA_Date
            });
            this.DirectAttendanceForm.controls
          }
          else {

            let date = new Date;
            let day = '';
            let month = '';
            if (date.getDate().toString().length > 1) {
              day = date.getDate().toString();
            }
            else {
              day = "0" + date.getDate();
            }
            if ((date.getMonth() + 1).toString().length > 1) {
              month = (date.getMonth() + 1).toString();
            }
            else {
              month = "0" + (date.getMonth() + 1);
            }
            let currentdate = (date.getFullYear() + '-' + month + '-' + day);
            let CurrentDayAttendance = res._Data.EmpAttendance.filter(a => a.EDA_Date == currentdate);
            if (CurrentDayAttendance[0] != null && CurrentDayAttendance.length > 0) {
              this.intime = CurrentDayAttendance[0].EDA_InTime;
              this.outtime = CurrentDayAttendance[0].EDA_OutTime;
              this.DirectAttendanceForm.patchValue({
                "LocationType": CurrentDayAttendance[0].EDA_LT
              });
              if (this.intime !== '00:00' && this.intime !== '' && this.intime !== null) {
                this.isCheckIn = false;
                this.btnText = "Checkout";
              }
              else {
                this.isCheckIn = true;
                this.btnText = "Checkin";
              }
            }

            //this.isPendingAttendance=false;
            for (var control in this.DirectAttendanceForm.controls) {
              this.DirectAttendanceForm.controls[control].disable();
            }
          }
          res._Data.EmpAttendance.forEach(item => {
            this.AttendanceDataSet.push({
              title: item.EDA_Att_Mark,
              date: item.EDA_Date,
              id: item.EDA_ID
            });
          });

          this.calendarOptions = {
            initialView: 'dayGridMonth',
            eventClick: this.handleEventClick.bind(this), // bind is important!
            dateClick: this.handleDateClick.bind(this),
            eventDidMount: function (info) {
              info.el.setAttribute('data-attendanceId', info.event.id)
              info.el.setAttribute('data-attendanceDayType', info.event.title)
            },
            eventContent: function (arg) {
              if (arg.event.title == "A") {
                arg.backgroundColor = "red";
                arg.borderColor = "red";
              }
              else if (arg.event.title == "P") {
                arg.backgroundColor = "green";
                arg.borderColor = "green";
              }
              else if (arg.event.title == "HO") {
                arg.backgroundColor = "#ffc107";
                arg.borderColor = "#ffc107";
              }
              else if (arg.event.title == "WD") {
                arg.backgroundColor = "blue";
                arg.borderColor = "blue";
              }
            },
            events: this.AttendanceDataSet
          };
        }
      }
    })
  }

  // Calendar Event Click Handler
  handleEventClick(arg) {

    this.AttendanceForm.reset();
    //=============== Check If Clicked Date is greater than today dont do anything
    let currentDate = new Date;
    currentDate.setHours(0, 0, 0, 0);
    let currentDateInNumber = Date.parse(currentDate.toDateString());
    let selectedDateInNumber = Date.parse(arg.event.start);
    if ((selectedDateInNumber > currentDateInNumber) || (arg.event.title == 'L')) {
      return false;
    }
    else {
      this.SelectedDate = arg.event.start.toDateString();
      // Update Form From Web API Start
      debugger
      let day = '';
      let month = '';
      if (arg.event.start.getDate().toString().length > 1) {
        day = arg.event.start.getDate().toString();
      }
      else {
        day = "0" + arg.event.start.getDate();
      }
      if ((arg.event.start.getMonth() + 1).toString().length > 1) {
        month = (arg.event.start.getMonth() + 1).toString();
      }
      else {
        month = "0" + (arg.event.start.getMonth() + 1);
      }
      this._empService.GetEmployeeAttendance1({
        "SGID": this._auth.getLoggedInUserid(),
        "AttendanceID": arg.event.id,
        "AttendanceDate": (arg.event.start.getFullYear() + '-' + month + '-' + day)
      }).subscribe((res) => {
        if (res.Message == 'Success') {
          if (res._Data != null && res._Data.EmpAttendance.length > 0) {
            if ((res._Data.EmpAttendance[0].EDA_ApprovalStatus != '20' && res._Data.EmpAttendance[0].EDA_ApprovalStatus != '25') && res._Data.EmpAttendance[0].EDA_Att_Mark == 'A' || res._Data.EmpAttendance[0].EDA_Att_Mark == 'HO' || res._Data.EmpAttendance[0].EDA_Att_Mark == 'WO') {
              for (var control in this.AttendanceForm.controls) {
                this.AttendanceForm.controls[control].enable();
              }
            }
            else {
              for (var control in this.AttendanceForm.controls) {
                this.AttendanceForm.controls[control].disable();
              }
            }
            this.m_LocationType = res._Data.EmpAttendance[0].EDA_LT;
            this.AttendanceForm.patchValue({
              "ManagerRemark": res._Data.EmpAttendance[0].EDA_ApproverRemark
            });
            //debugger
            this.AttendanceForm.patchValue({
              AttendanceID: res._Data.EmpAttendance[0].EDA_ID,
              DayType: arg.event.title,
              LocationType: res._Data.EmpAttendance[0].EDA_LT,
              AttendanceStartTime: res._Data.EmpAttendance[0].EDA_InTime,
              AttendanceEndTime: res._Data.EmpAttendance[0].EDA_OutTime,
              AttendanceRemark: res._Data.EmpAttendance[0].EDA_Remarks,
              AttendanceDate: res._Data.EmpAttendance[0].EDA_Date == '' ? (arg.event.start.getFullYear() + '-' + month + '-' + day) : res._Data.EmpAttendance[0].EDA_Date
            });

            this.AttendanceForm.controls['AttendanceDate'].reset({ value: (arg.event.start.getFullYear() + '-' + month + '-' + day), disabled: true });

            this._approvalFlag = res._Data.EmpAttendance[0].EDA_ApprovalStatus;
            this._attendancemark = res._Data.EmpAttendance[0].EDA_Att_Mark;
            this.GetAttendanceIndicator();
          }
          else {
            for (var control in this.AttendanceForm.controls) {
              this.AttendanceForm.controls[control].enable();
            }
            this._approvalFlag = res._Data.EmpAttendance[0].EDA_ApprovalStatus;
            this._attendancemark = res._Data.EmpAttendance[0].EDA_Att_Mark;
            this.GetAttendanceIndicator();
          }
          this.AttendanceForm.controls['ManagerRemark'].disable();
        }
      });
      this.updateScreen.nativeElement.classList.add('showUpdateScreen');
    }

  }

  // Calendar Date Click Handler
  handleDateClick(date) {
    //debugger;
    this.AttendanceForm.reset();
    let currentDate = new Date;
    currentDate.setHours(0, 0, 0, 0);
    let currentDateInNumber = Date.parse(currentDate.toDateString());
    let selectedDateInNumber = Date.parse(date.dateStr);
    if (selectedDateInNumber > currentDateInNumber) {
      return false;
    }
    else {
      this.SelectedDate = date.date.toDateString();
      this.AttendanceForm.patchValue({
        AttendanceDate: date.dateStr
      });
      // Update Form From Web API Start
      let id = '';
      let daytype = '';

      if (date.dayEl.childNodes[0].children[1].children[0].children[0] !== undefined) {
        id = date.dayEl.childNodes[0].children[1].children[0].children[0].getAttribute('data-attendanceid');
        daytype = date.dayEl.childNodes[0].children[1].children[0].children[0].getAttribute('data-attendancedaytype');
        if (daytype == 'L') {
          return false;
        }
        if (id == null || id == undefined) {
          id = '';
        }
      } else {
        id = '';
      }
      if (daytype == null || daytype == undefined) {
        daytype = '';
      }
      else {
        daytype = '';
      }
      if(id=='' || id==undefined || id=='0' || id==null){
        return false;
      }else{
        this._empService.GetEmployeeAttendance1({
          "SGID": this._auth.getLoggedInUserid(),
          "AttendanceID": id,
          "AttendanceDate": date.dateStr
        }).subscribe((res) => {
          if (res.Message == 'Success') {
            if (res._Data != null && res._Data.EmpAttendance.length > 0) {
              this._approvalFlag = res._Data.EmpAttendance[0].EDA_ApprovalStatus;
              this._attendancemark = res._Data.EmpAttendance[0].EDA_Att_Mark;
              this.GetAttendanceIndicator();
              this.m_LocationType = res._Data.EmpAttendance[0].EDA_LT;
              this.AttendanceForm.patchValue({
                "ManagerRemark": res._Data.EmpAttendance[0].EDA_ApproverRemark
              });
              this.AttendanceForm.patchValue({
                AttendanceID: res._Data.EmpAttendance[0].EDA_ID,
                LocationType: res._Data.EmpAttendance[0].EDA_LT,
                AttendanceStartTime: res._Data.EmpAttendance[0].EDA_InTime,
                AttendanceEndTime: res._Data.EmpAttendance[0].EDA_OutTime,
                AttendanceRemark: res._Data.EmpAttendance[0].EDA_Remarks,
                AttendanceDate: res._Data.EmpAttendance[0].EDA_Date == '' ? (date.dateStr) : res._Data.EmpAttendance[0].EDA_Date
              });
              if (res._Data.EmpAttendance[0].EDA_ApprovalStatus != '20' && (res._Data.EmpAttendance[0].EDA_Att_Mark == 'A' ||
                res._Data.EmpAttendance[0].EDA_Att_Mark == 'HO' ||
                res._Data.EmpAttendance[0].EDA_Att_Mark == 'WO')) { //&& date.dayEl.childNodes[0].children[1].children[0].children[0].getAttribute('data-attendancedaytype')=='A'
                for (var control in this.AttendanceForm.controls) {
                  this.AttendanceForm.controls[control].enable();
                }
              }
              else {
                for (var control in this.AttendanceForm.controls) {
                  this.AttendanceForm.controls[control].disable();
                }
              }
            }
            else {
              this.AttendanceForm.patchValue({
                AttendanceID: '',
                LocationType: '',
                AttendanceStartTime: this.formatAMPM(new Date()),
                AttendanceEndTime: this.formatAMPM(new Date()),
                AttendanceDate: date.dateStr,
                DayType: daytype
              });
              for (var control in this.AttendanceForm.controls) {
                this.AttendanceForm.controls[control].enable();
              }
            }
          }
        });
        this.AttendanceForm.controls['ManagerRemark'].disable();
        this.updateScreen.nativeElement.classList.add('showUpdateScreen');
      }
      
    }
  }

  GetAttendanceIndicator() {
    if (this._approvalFlag == "20" && this._attendancemark == "A") {
      return "Rejected Attendance";
    }
    else if (this._approvalFlag == "15" && this._attendancemark == "A") {
      return "Request For Modification";
    }
    else if (this._approvalFlag == "10" && this._attendancemark == "P") {
      return "Submitted Attendance";
    }
    else if(this._attendancemark == "HO"){
      return "Holiday";
    }
    else if(this._attendancemark == "WO"){
      return "Weekly Off";
    }
    else if (this._approvalFlag == "25" && this._attendancemark == "P") {
      return "Approved Attendance";
    }
    else if ((this._approvalFlag == "" || this._approvalFlag == "5" || this._approvalFlag == "0") && this._attendancemark == "A") {
      return "Pending Attendance";
    }
  }
  updateScreenClick(id) {
    this.AttendanceForm.reset();
    this._empService.GetEmployeeAttendance1({
      "SGID": this._auth.getLoggedInUserid(),
      "AttendanceID": id
    }).subscribe((res) => {
      console.log(res);
      if (res.Message == 'Success') {
        if (res._Data != null) {
          this.m_LocationType = res._Data.EmpAttendance[0].EDA_LT;
          this._attendancemark = res._Data.EmpAttendance[0].EDA_Att_Mark;
          this._approvalFlag = res._Data.EmpAttendance[0].EDA_ApprovalStatus;
          this.GetAttendanceIndicator();
          if (res._Data.EmpAttendance[0].EDA_Att_Mark != "A") {
            this.AttendanceForm.controls['AttendanceStartTime'].reset({ value: res._Data.EmpAttendance[0].EDA_InTime, disabled: true });
            this.AttendanceForm.controls['AttendanceEndTime'].reset({ value: res._Data.EmpAttendance[0].EDA_OutTime, disabled: false });
          }
          else {
            this.AttendanceForm.controls['AttendanceStartTime'].reset({ value: res._Data.EmpAttendance[0].EDA_InTime, disabled: false });
            this.AttendanceForm.controls['AttendanceEndTime'].reset({ value: res._Data.EmpAttendance[0].EDA_OutTime, disabled: false });
          }
          this.SelectedDate = res._Data.EmpAttendance[0].EDA_StrAttendanceDate;
          //debugger;
          if (res._Data.EmpAttendance[0].EDA_ApproverRemark != '' && res._Data.EmpAttendance[0].EDA_ApproverRemark != null) {
            this.isManagerRemarkPresent = true;
          } else {
            this.isManagerRemarkPresent = false;
          }

          this.AttendanceForm.patchValue({
            AttendanceID: res._Data.EmpAttendance[0].EDA_ID,
            AttendanceDate: res._Data.EmpAttendance[0].EDA_Date,
            LocationType: res._Data.EmpAttendance[0].EDA_LT,
            AttendanceStartTime: res._Data.EmpAttendance[0].EDA_InTime,
            AttendanceEndTime: res._Data.EmpAttendance[0].EDA_OutTime,
            AttendanceRemark: res._Data.EmpAttendance[0].EDA_Remarks,
            DayType: res._Data.EmpAttendance[0].EDA_DT,
            ManagerRemark: res._Data.EmpAttendance[0].EDA_ApproverRemark
          });

          this.AttendanceForm.controls['LocationType'].reset({ value: res._Data.EmpAttendance[0].EDA_LT, disabled: false });

          let date = new Date();

          if (this.AttendanceForm.controls["AttendanceDate"].value == date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate()) {
            this.AttendanceForm.controls["AttendanceEndTime"].clearValidators();
            this.AttendanceForm.controls["AttendanceEndTime"].updateValueAndValidity();
          }
          else {
            this.AttendanceForm.controls["AttendanceEndTime"].setValidators(Validators.required);
            this.AttendanceForm.controls["AttendanceEndTime"].updateValueAndValidity();
          }
          this.AttendanceForm.controls['AttendanceDate'].reset({ value: res._Data.EmpAttendance[0].EDA_Date, disabled: true });

          if (res._Data.EmpAttendance[0].EDA_ApprovalStatus == '20') {
            for (var control in this.AttendanceForm.controls) {
              this.AttendanceForm.controls[control].disable();
            }
          }
          else {
            for (var control in this.AttendanceForm.controls) {
              this.AttendanceForm.controls[control].enable();
            }
          }
        }
      }
      this.AttendanceForm.controls['ManagerRemark'].disable();
    })
    //this.SelectedDate = null;
    //this._defaulttime = this.formatAMPM(new Date());
    this.updateScreen.nativeElement.classList.add('showUpdateScreen');
  }

  //Change Location Type For Direct Attendance
  changeLocationType(val) {
    this.DirectAttendanceForm.patchValue({
      "LocationType": val
    });
  }


  ViewEmpAttendance() {
    this._router.navigate(['view-attendance']);
  }

  // Open Manual Entry Popup
  OpenManualEntryPage() {
    this.AttendanceForm.reset();
    this._empService.GetEmployeeAttendance1({
      "SGID": this._auth.getLoggedInUserid()
    }).subscribe((res) => {
      let date = new Date();
      debugger;
      this.SelectedDate = date.toDateString();
      //let currentdate = (date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
      let day = '';
      let month = '';
      if (date.getDate().toString().length > 1) {
        day = date.getDate().toString();
      }
      else {
        day = "0" + date.getDate();
      }
      if ((date.getMonth() + 1).toString().length > 1) {
        month = (date.getMonth() + 1).toString();
      }
      else {
        month = "0" + (date.getMonth() + 1);
      }
      let currentdate = (date.getFullYear() + '-' + month + '-' + day);
      if (res.Message == 'Success') {
        if (res._Data != null) {
          const CurrentDayAttendance = res._Data.EmpAttendance.filter(a => a.EDA_TodayAttendanceStatus == 'Pending');
          if (CurrentDayAttendance[0] != null && CurrentDayAttendance.length > 0) {
            this._attendancemark = CurrentDayAttendance[0].EDA_Att_Mark;
            this._approvalFlag = CurrentDayAttendance[0].EDA_ApprovalStatus;
            this.GetAttendanceIndicator();
            this.intime = CurrentDayAttendance[0].EDA_InTime == "" ? "00:00" : CurrentDayAttendance[0].EDA_InTime;
            this.outtime = CurrentDayAttendance[0].EDA_OutTime == "" ? "00:00" : CurrentDayAttendance[0].EDA_OutTime;
            if (this.intime !== '00:00' && this.intime !== '') {
              this.isCheckIn = false;
              this.btnText = "Checkout";
            }
            else {
              this.AttendanceForm.controls['LocationType'].reset({ value: res._Data.EmpAttendance[0].EDA_LT, disabled: false });
            }
            let officeInTime = '';
            let officeOutTime = '';
            if (CurrentDayAttendance[0].EDA_InTime == "" || CurrentDayAttendance[0].EDA_InTime == "00:00") {
              officeInTime = "";
            }
            else {
              officeInTime = CurrentDayAttendance[0].EDA_InTime;
            }
            if (CurrentDayAttendance[0].EDA_OutTime == "" || CurrentDayAttendance[0].EDA_OutTime == "00:00") {
              officeOutTime = "";
            }
            else {
              officeOutTime = CurrentDayAttendance[0].EDA_OutTime;
            }
            this.AttendanceForm.patchValue({
              "LocationType": CurrentDayAttendance[0].EDA_LT,
              "AttendanceDate": CurrentDayAttendance[0].EDA_Date,
              "AttendanceStartTime": officeInTime,
              "AttendanceEndTime": officeOutTime,
              "AttendanceRemark": CurrentDayAttendance[0].EDA_Remarks,
              "AttendanceID": CurrentDayAttendance[0].EDA_ID,
              "DayType": CurrentDayAttendance[0].EDA_DT
            });

            if (currentdate == this.AttendanceForm.controls["AttendanceDate"].value) {
              this.AttendanceForm.controls["AttendanceEndTime"].clearValidators();
              this.AttendanceForm.controls["AttendanceEndTime"].updateValueAndValidity();
            }
            else {
              this.AttendanceForm.controls["AttendanceEndTime"].setValidators(Validators.required);
              this.AttendanceForm.controls["AttendanceEndTime"].updateValueAndValidity();
            }
          }
          else {
            let CurrentDayAttendance = res._Data.EmpAttendance.filter(a => a.EDA_Date == currentdate);
            if (CurrentDayAttendance[0] != null && CurrentDayAttendance.length > 0) {
              this.intime = CurrentDayAttendance[0].EDA_InTime;
              this.outtime = CurrentDayAttendance[0].EDA_OutTime;
              this._attendancemark = CurrentDayAttendance[0].EDA_Att_Mark;
              this._approvalFlag = CurrentDayAttendance[0].EDA_ApprovalStatus;
              this.GetAttendanceIndicator();
              if (this.intime !== '00:00' && this.intime !== '' && this.intime !== null) {
                this.isCheckIn = false;
                this.btnText = "Checkout";
              }
              else {
                this.isCheckIn = true;
                this.btnText = "Checkin";
              }
              this.AttendanceForm.patchValue({
                "LocationType": CurrentDayAttendance[0].EDA_LT,
                "AttendanceDate": CurrentDayAttendance[0].EDA_Date,
                "AttendanceStartTime": CurrentDayAttendance[0].EDA_InTime,
                "AttendanceEndTime": CurrentDayAttendance[0].EDA_OutTime,
                "AttendanceRemark": CurrentDayAttendance[0].EDA_Remarks,
                "AttendanceID": CurrentDayAttendance[0].EDA_ID,
                "DayType": CurrentDayAttendance[0].EDA_DT
              });
            }
            if (currentdate == this.AttendanceForm.controls["AttendanceDate"].value) {
              this.AttendanceForm.controls["AttendanceEndTime"].clearValidators();
              this.AttendanceForm.controls["AttendanceEndTime"].updateValueAndValidity();
            }
            else {
              this.AttendanceForm.controls["AttendanceEndTime"].setValidators(Validators.required);
              this.AttendanceForm.controls["AttendanceEndTime"].updateValueAndValidity();
            }
            if (CurrentDayAttendance[0].EDA_Att_Mark == 'P' && (CurrentDayAttendance[0].EDA_ApprovalStatus == '20' || CurrentDayAttendance[0].EDA_ApprovalStatus == '10')) {
              for (var control in this.AttendanceForm.controls) {
                this.AttendanceForm.controls[control].disable();
              }
            }
            else {
              for (var control in this.AttendanceForm.controls) {
                this.AttendanceForm.controls[control].enable();
              }
            }
          }
        }
      }
    });
    this.AttendanceForm.controls['ManagerRemark'].disable();
    this.updateScreen.nativeElement.classList.add('showUpdateScreen');
  }
  // Close Update attendance Screen
  CloseCanvas() {
    this.updateScreen.nativeElement.classList.remove('showUpdateScreen');
  }

  // Set & Get Default time
  formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
  }

  // Update Attendance From Update Screen
  UpdateAttendance() {
    debugger;
    if (this.modify_time(this.AttendanceForm.get("AttendanceStartTime").value, this.AttendanceForm.get("AttendanceEndTime").value)) {
      if (this.AttendanceForm.controls["AttendanceEndTime"].value == "" || this.AttendanceForm.controls["AttendanceEndTime"].value == "00:00") {
        this.AttendanceForm.patchValue({
          "AttendanceEndTime": "00:00"
        });
      }
      this.AddEmpAttendance({
        "SGID": this._auth.getLoggedInUserid(),
        "AttendanceID": this.AttendanceForm.controls["AttendanceID"].value,
        "AttendanceStartTime": this.AttendanceForm.controls["AttendanceStartTime"].value,
        "AttendanceEndTime": this.AttendanceForm.controls["AttendanceEndTime"].value,
        "AttendanceEntryType": "Direct",
        "AttendanceRemark": this.AttendanceForm.controls["AttendanceRemark"].value,
        "DayType": this.AttendanceForm.controls["DayType"].value,
        "LocationType": this.AttendanceForm.controls["LocationType"].value,
        "AttendanceDate": this.AttendanceForm.controls["AttendanceDate"].value
      });
    }
  }

  AddEmpAttendance(_attendanceObj: any) {
    this._empService.AddEmployeeAttendance(_attendanceObj).subscribe((res) => {
      console.log(res);
      if (res.Message == 'Success' && res.Status == 'SU') {
        this.updateScreen.nativeElement.classList.remove('showUpdateScreen');
        this.AttendanceForm.reset();
        this.PopuplateCalendarAttendance(this._auth.getLoggedInUserid(), '');
        window.location.reload();
      }
      else if (res.Status == 'EX') {
        alert('something went wrong');
      }
    })
  }


  onCheckinCheckOut() {

    if (this.isCheckIn == true) {
      this.intime = this.formatAMPM(new Date);
      this.btnText = "Check Out";
    }
    else {
      this.outtime = this.formatAMPM(new Date);
      this.btnText = "Check In";
    }
    this.DirectAttendanceForm.patchValue({
      "AttendanceEndTime": this.outtime,
      "AttendanceStartTime": this.intime
    });

    this.AddEmpAttendance({
      "SGID": this._auth.getLoggedInUserid(),
      "AttendanceID": this.DirectAttendanceForm.controls["AttendanceID"].value,
      "AttendanceStartTime": this.DirectAttendanceForm.controls["AttendanceStartTime"].value,
      "AttendanceEndTime": this.DirectAttendanceForm.controls["AttendanceEndTime"].value,
      "AttendanceEntryType": "Direct",
      "AttendanceRemark": this.DirectAttendanceForm.controls["AttendanceRemark"].value,
      "DayType": this.DirectAttendanceForm.controls["DayType"].value,
      "LocationType": this.DirectAttendanceForm.controls["LocationType"].value,
      "AttendanceDate": this.DirectAttendanceForm.controls["AttendanceDate"].value
    });
  }

  getSelectedDate(date) {
    if (date == this.AttendanceForm.controls["AttendanceDate"].value) {
      this.AttendanceForm.controls["AttendanceEndTime"].clearValidators();
      this.AttendanceForm.controls["AttendanceEndTime"].updateValueAndValidity();
    }
    else {
      this.AttendanceForm.controls["AttendanceEndTime"].setValidators(Validators.required);
      this.AttendanceForm.controls["AttendanceEndTime"].updateValueAndValidity();
    }
  }

  setStartTime(event) {
    this.AttendanceForm.patchValue({
      "AttendanceStartTime": event
    });
    this.modify_time(this.AttendanceForm.get("AttendanceStartTime").value, this.AttendanceForm.get("AttendanceEndTime").value)
  }

  setEndTime(event) {
    this.AttendanceForm.patchValue({
      "AttendanceEndTime": event
    });
    this.modify_time(this.AttendanceForm.get("AttendanceStartTime").value, this.AttendanceForm.get("AttendanceEndTime").value)
  }

  modify_time(startitme, enttime) {
    if(enttime=='12:00 AM' || enttime=='12:00 am'){
      alert('End time should not be 12:00 AM');
      return false;
    }
    var start_time = startitme;
    var end_time = enttime;
    start_time = start_time.split(" ");
    var time = start_time[0].split(":");
    var stime = time[0];
    if ((start_time[1] == "PM" || start_time[1] == "pm") && stime < 12) stime = parseInt(stime) + 12;
    start_time = stime + ":" + time[1];

    end_time = end_time.split(" ");
    var time1 = end_time[0].split(":");
    var etime = time1[0];
    if ((end_time[1] == "PM" || end_time[1] == "pm") && etime < 12) etime = parseInt(etime) + 12;
    end_time = etime + ":" + time1[1];

    if (start_time != '' && end_time != '') {
      start_time = start_time.replace(':', '');
      end_time = end_time.replace(':', '');
      if ((start_time * 1) >= (end_time * 1)) {
        alert('Start time should be less then or equal to end time');
        return false;
      } else {
        return true;
      }
    }
  }
}
