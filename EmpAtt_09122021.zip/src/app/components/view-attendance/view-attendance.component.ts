import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { EmployeeAttendanceService } from 'src/app/services/employee-attendance.service';
declare var $: any;
@Component({
  selector: 'app-view-attendance',
  templateUrl: './view-attendance.component.html',
  styleUrls: ['./view-attendance.component.css']
})
export class ViewAttendanceComponent implements OnInit {
  ApprovalFlag: number;
  ReviseRejectAttedanceData: any = [];
  @ViewChild('reviseScreen') reviseScreen: ElementRef;
  @ViewChild('approveRejectContainer') approveRejectContainer: ElementRef;
  ReviseInfoDetailForm: FormGroup;
  @ViewChild('showPendingLeaves') showPendingLeaves: ElementRef;
  @ViewChild('reviseModal') reviseModal: ElementRef;
  EmployeeAttendance: any = [];
  SelectedEmployeeAttendance: any = [];
  SelectedTitle: string = '';
  FinalApproveRejectArray: any = [];
  AttendanceFlag: boolean = false;
  UncheckSelectAll: boolean = false;
  ReviseRejectTitle: string = '';
  constructor(private _auth: AuthService, private _empService: EmployeeAttendanceService, private formBuilder: FormBuilder,) { }

  ngOnInit(): void {
    this.createForm();
    this.getEmpUnderManager();
  }

  createForm() {
    this.ReviseInfoDetailForm = this.formBuilder.group({
      Remark: ['', Validators.required],
      AttendanceID: [''],
      EmpSGID: [],
      MgrEmpCode: [this._auth.getLoggedInUserid(), Validators.required],
      ManagerEmail: [''],
      EmployeeEmail: [''],
      EmployeeName: [''],
      ReviseMailBody: [''],
      RejectMailBody: [''],
      ManagerName: ['']
    });
  }

  getEmpUnderManager() {
    this._empService.GetEmpUnderManager({ "SGID": this._auth.getLoggedInUserid() }).subscribe((res) => {
      console.log(res);
      if (res.Message == 'Success' && res.Status == 'SU') {
        if (res._Data != null) {
          if (res._Data.EmpUnderManager != null) {
            if (res._Data.EmpUnderManager.EmpData != null) {
              if (res._Data.EmpUnderManager.EmpData.length > 0) {
                this.EmployeeAttendance = res._Data.EmpUnderManager.EmpData;
              }
            } else {
              this.EmployeeAttendance = null;
            }
          }
        }
      }
    })
  }

  getSelectedEmpAttendance(managerSGID: string, empSGID: string, attendanceFlag: string) {
    debugger;
    this.approveRejectContainer.nativeElement;
    this._empService.GetEmpUnderManager({ "SGID": managerSGID, "AttendanceFlag": attendanceFlag, "SelectedEmployeeSGID": empSGID }).subscribe((res) => {
      console.log(res);
      if (res.Message == 'Success' && res.Status == 'SU') {
        if (res._Data != null) {
          //debugger;
          if (res._Data.EmpUnderManager != null) {
            if (res._Data.EmpUnderManager.EmpData != null) {
              if (res._Data.EmpUnderManager.EmpData.length > 0) {
                this.SelectedEmployeeAttendance = res._Data.EmpUnderManager.EmpData[0].EmployeeAttendance;
              }
            }
            else {
              this.SelectedEmployeeAttendance = null;
            }
          }
        }
      }
    })
  }



  GetSelectedAttendance(attendanceID: string, isApprove: boolean, EmpSGID: string) {
debugger;
    let jsonarray = this.FinalApproveRejectArray;
    if (isApprove == false) {
      this.FinalApproveRejectArray.forEach(function (e, index) {
        if (attendanceID == e.AttendanceID) {
          jsonarray.splice(index, 1);
        }
      });
      this.FinalApproveRejectArray = jsonarray;
    }
    else {
      this.FinalApproveRejectArray.push({
        "SGID": this._auth.getLoggedInUserid(),
        "SelectedEmployeeSGID": EmpSGID,
        "AttendanceID": attendanceID,
        "AttendanceFlag": isApprove == true ? '20' : '10'
      })
    }

    // Remove Select All Check if no of checkbox!= selected checkbox
    let totalSelectedCheckbox = 0;
    let totalCheckbox = this.approveRejectContainer.nativeElement.children.length;

    for (let iCheckbox = 0; iCheckbox < this.approveRejectContainer.nativeElement.children.length; iCheckbox++) {
      if (this.approveRejectContainer.nativeElement.children[iCheckbox].children[0].children[0].children[0].children[0].checked == true) {

        totalSelectedCheckbox = totalSelectedCheckbox + 1;
      }
    }
    if(totalSelectedCheckbox!=totalCheckbox){
      this.UncheckSelectAll=false;
    }
    else{
      this.UncheckSelectAll=true;
    }

    //End
  }

  showPendingLeave(empsgid, flag, title) {
    this.UncheckSelectAll = false;
    if (flag == 'P') {
      this.AttendanceFlag = true;
    }
    else {
      this.AttendanceFlag = false;
    }
    this.FinalApproveRejectArray = [];
    this.getSelectedEmpAttendance(this._auth.getLoggedInUserid(), empsgid, flag);
    this.SelectedTitle = title;
    this.showPendingLeaves.nativeElement.setAttribute('style', 'left: 0%;');
  }

  ApplyBackgroundbseOnStatus(status){
    if(status=="20"){
return 'rejected-img';
    }
    else if(status=="25"){
      return 'approved-img';
    }
    else{
      return '';
    }
  }
  submitReviseAttendance(id, empCode, approvalFlag, managerEmail, employeeEmail, empname, revisemailbody, rejectmailbody,managerName, RejectReviseTitle) {
    debugger
    this.ReviseRejectTitle = RejectReviseTitle;
    // Get Selected Employee Attendance Detail 
    this._empService.GetEmpUnderManager({ "SGID": this._auth.getLoggedInUserid(), "SelectedEmployeeSGID": empCode, "AttendanceID": id }).subscribe((res) => {
      console.log(res);
      if (res.Message == 'Success' && res.Status == 'SU') {
        if (res._Data != null) {
          if (res._Data.EmpUnderManager != null) {
            if (res._Data.EmpUnderManager.EmpData != null) {
              if (res._Data.EmpUnderManager.EmpData.length > 0) {
                this.ReviseRejectAttedanceData = res._Data.EmpUnderManager.EmpData[0].EmployeeAttendance;
              }
            } else {
              this.ReviseRejectAttedanceData = null;
            }
          }
        }
      }
    })
    // End
    this.ApprovalFlag = approvalFlag;
    this.ReviseInfoDetailForm.patchValue({
      EmpSGID: empCode,
      AttendanceID: id,
      EmployeeEmail: employeeEmail,
      ManagerEmail: managerEmail,
      EmployeeName: empname,
      ReviseMailBody: revisemailbody,
      RejectMailBody: rejectmailbody,
      ManagerName: managerName
    });
    this.reviseScreen.nativeElement.setAttribute('style', 'left: 0');
  }

  CloseReviseModal() {
    this.reviseScreen.nativeElement.setAttribute('style', 'left: 100%');
  }

  submitReviseDetail() {
    this._empService.ApproveRejectAttendance({
      "SGID": this.ReviseInfoDetailForm.get('MgrEmpCode').value,
      "AttendanceFlag": this.ApprovalFlag,
      "AttendanceID": this.ReviseInfoDetailForm.get('AttendanceID').value,
      "SelectedEmployeeSGID": this.ReviseInfoDetailForm.get('EmpSGID').value,
      "AttendanceRemark": this.ReviseInfoDetailForm.get('Remark').value,
      "ManagerEmail": this.ReviseInfoDetailForm.get('ManagerEmail').value,
      "EmployeeEmail": this.ReviseInfoDetailForm.get('EmployeeEmail').value,
      "EmployeeName": this.ReviseInfoDetailForm.get('EmployeeName').value,
      "ReviseMailBody": this.ReviseInfoDetailForm.get('ReviseMailBody').value,
      "RejectMailBody": this.ReviseInfoDetailForm.get('RejectMailBody').value,
      "ManagerName": this.ReviseInfoDetailForm.get('ManagerName').value
    }).subscribe((res) => {
      console.log(res);
      this.FinalApproveRejectArray = [];
      this.reviseScreen.nativeElement.setAttribute('style', 'left: 100%');
      this.hidePendingLeave();
      this.getEmpUnderManager();
      this.ReviseInfoDetailForm.reset();
    });
  }

  submitSelectedAttendance(approveRejectFlag) {
    let Ids = '';
    let selectedEmpCode: string = '';
    this.FinalApproveRejectArray.forEach(element => {
      Ids = Ids + ',' + element.AttendanceID;
      selectedEmpCode = element.SelectedEmployeeSGID
    });
    console.log(approveRejectFlag);
    console.log(this.FinalApproveRejectArray);
    this._empService.ApproveRejectAttendance({
      "SGID": this._auth.getLoggedInUserid(),
      "AttendanceFlag": approveRejectFlag,
      "AttendanceID": Ids,
      "SelectedEmployeeSGID": selectedEmpCode
    }).subscribe((res) => {
      console.log(res);
      this.FinalApproveRejectArray = [];
      this.showPendingLeaves.nativeElement.setAttribute('style', 'left: 100%;');
      this.getEmpUnderManager();
    })
  }

  hidePendingLeave() {
    this.showPendingLeaves.nativeElement.setAttribute('style', 'left: 100%;');
    this.FinalApproveRejectArray = [];
  }

  SelectAll(event) {
    let jsonarray = this.FinalApproveRejectArray;
    for (var iElement = 0; iElement < this.approveRejectContainer.nativeElement.children.length; iElement++) {
      if (event == true) {
        this.approveRejectContainer.nativeElement.children[iElement].children[0].children[0].children[0].children[0].checked = true;
        let sgid = this.approveRejectContainer.nativeElement.children[iElement].children[0].children[0].children[0].children[0].getAttribute('data-sgid');
        let attendanceId = this.approveRejectContainer.nativeElement.children[iElement].children[0].children[0].children[0].children[0].getAttribute('data-id');
        this.FinalApproveRejectArray.push({
          "SGID": this._auth.getLoggedInUserid(),
          "SelectedEmployeeSGID": sgid,
          "AttendanceID": attendanceId,
          "AttendanceFlag": '20'
        });
      }
      else {
        this.approveRejectContainer.nativeElement.children[iElement].children[0].children[0].children[0].children[0].checked = false;
        let attendanceId = this.approveRejectContainer.nativeElement.children[iElement].children[0].children[0].children[0].children[0].getAttribute('data-id');
        this.FinalApproveRejectArray.forEach(function (e, index) {
          if (attendanceId == e.AttendanceID) {
            jsonarray.splice(index, 1);
          }
        });
        this.FinalApproveRejectArray = jsonarray;
      }
    }
  }
}
