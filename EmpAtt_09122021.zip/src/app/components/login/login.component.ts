import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from 'src/app/services/auth.service';
import { PushNotificationMessageService } from 'src/app/services/push-notification-message.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  message=null;
  //user: UserCredential= new UserCredential;
  constructor(private formBuilder: FormBuilder,
    private http: HttpClient, private router: Router, private _authservice: AuthService,private messagingService:PushNotificationMessageService) { }

  ngOnInit(): void {
    this._authservice.logoutSession();
    this.createForm();
    this.messagingService.requestPermission()
    this.messagingService.receiveMessage()
    this.message = this.messagingService.currentMessage
  }

  createForm() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      isLive: ['true']
    });
  }

  ChangeEnvironmentFlag(event) {
      this.loginForm.patchValue({
        "isLive": event.checked
      });
      if(event.checked==false){
        this.loginForm.get('password').disable();
      }
      else{
        this.loginForm.get('password').enable();
      }
  }
  submit() {
    // let body = new URLSearchParams();
    // body.set("username", this.loginForm.get('username').value);
    // body.set("password", this.loginForm.get('password').value);
    // body.set("grant_type", "password");

    let body = `username=${this.loginForm.get('username').value}&password=${this.loginForm.get('password').value}&grant_type=password&isLive=${this.loginForm.get('isLive').value}`;

    this._authservice.AuthenticateUser(body).subscribe((result) => {
      //debugger;
      console.log(result);
    }, err => {
      console.log(err);
      if (err.status == 400) {
        alert('invalid username & password');
      }
    })

  }
}
