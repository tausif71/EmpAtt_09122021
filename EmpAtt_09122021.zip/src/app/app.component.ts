import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { OnlineOfflineNetworkCheckingService } from './interceptors/network-checking-interceptor';
import { PushNotificationMessageService } from './services/push-notification-message.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  message;
  showalter: boolean = false;
  isOffline = null;
  @ViewChild('networkoff') networkoff:ElementRef;
  @ViewChild('networkon') networkon:ElementRef;
  constructor(private router:Router,private pushNotificationMsg:PushNotificationMessageService,
    private _olineOfline: OnlineOfflineNetworkCheckingService){
      this.checkingNewStatus(_olineOfline);
    }
  title = 'Attendance PWA';

  ngOnInit(){
    this.pushNotificationMsg.requestPermission()
  this.pushNotificationMsg.receiveMessage()
  this.message = this.pushNotificationMsg.currentMessage
  }
  /**
   * Check if the router url contains the specified route
   *
   * @param {string} route
   * @returns
   * @memberof MyComponent
   */
   showContent(): boolean {
    if (this.router.url.indexOf('login') > -1) {
      return false;
    }
    return true;
  }

  HideNetWorkOff(){
    this.networkoff.nativeElement.classList.add('hide');
  }
  HideNetWorkOn(){
    this.networkon.nativeElement.classList.add('hide');
  }
  
  applybgEmployee():string{
    if (this.router.url=="/"|| this.router.url=="/login" || this.router.url.includes('/login')) {
      return 'bgEmployee'
    }
    else{
      return ''
    }
  }

  /***********************************************************************
   * Check if internet connection is active or not
   *
   * @param interceptor
   * @returns return boolean value
   * @memberof customer interceptor to check network status
   ***********************************************************************/
   private checkingNewStatus(
    _onlineOfline: OnlineOfflineNetworkCheckingService
  ) {
    _onlineOfline.connectionChanged.subscribe((online) => {
debugger;
      if (online) {
        console.log('went online - sending all stored items');
        this.isOffline = false;
        this.showalter = true;
      } else {
        console.log('went offline, storing in indexdb');
        this.showalter = true;
        this.isOffline = true;
      }
    });
  }

}
