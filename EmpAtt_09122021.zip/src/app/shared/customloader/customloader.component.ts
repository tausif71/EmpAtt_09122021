import { Component, OnInit } from '@angular/core';
import { LoaderService } from 'src/app/services/loader.service';


@Component({
  selector: 'app-customloader',
  templateUrl: './customloader.component.html',
  styleUrls: ['./customloader.component.css']
})
export class CustomloaderComponent implements OnInit {

  loading: boolean;
  constructor(private loaderService: LoaderService) { 
    this.loaderService.isLoading.subscribe((v) => {
      this.loading = v;
    });

  }

  ngOnInit(): void {
  }

}
