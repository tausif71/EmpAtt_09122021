import { AfterViewInit, Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, AfterViewInit {
  profilePic: string;
  username: string;
  designation: string;
  constructor(private _authService: AuthService, private _router: Router, private ngzone: NgZone) { }

  ngOnInit(): void {
    //this.profilePic = `https://portal.saint-gobain.com/static/profile/pictures/${localStorage.getItem('profilepic')}.jpg`;
    this.profilePic='assets/img/avatar.png';
    this.username = localStorage.getItem('username');
    this.designation = localStorage.getItem('designation');
  }

  ngAfterViewInit() {
    this.ngzone.runOutsideAngular(() => {
      $('.sidebar-toggler').on('click', function(e) {
        e.preventDefault();
        $('.sidebar-header .sidebar-toggler').toggleClass('active not-active');
        if (window.matchMedia('(min-width: 992px)').matches) {
          e.preventDefault();
          $('body').toggleClass('sidebar-folded');
        } else if (window.matchMedia('(max-width: 991px)').matches) {
          e.preventDefault();
          $('body').toggleClass('sidebar-open');
        }
      });
    })
  }

  OpenMenu() {

  }
  logOut() {
    this._authService.logoutSession();
  }
}
