import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpErrorResponse,
} from '@angular/common/http';
import { AuthService } from '../services/auth.service';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private authService: AuthService,private router:Router) {}
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (this.authService.isLoggedIn()) {
       // debugger
      const authToken = this.authService.getAuthorizationToken();
      if (authToken != '' && authToken !== undefined) {
        req = req.clone({
          setHeaders: {
            Authorization: `Bearer  ` + authToken,
            'Content-Type': 'application/json'
          },
        });
      } else {
        this.authService.logoutSession();
      }
    }
    //return next.handle(req);
    return next.handle(req).pipe(
      catchError((err: HttpErrorResponse) => {
        if (err.status === 401) {
          this.router.navigate(['login']);
        }
        return throwError(err);
      })
    );
  }
}
