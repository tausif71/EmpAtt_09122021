import { TestBed } from '@angular/core/testing';

import { PushNotificationMessageService } from './push-notification-message.service';

describe('PushNotificationMessageService', () => {
  let service: PushNotificationMessageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PushNotificationMessageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
