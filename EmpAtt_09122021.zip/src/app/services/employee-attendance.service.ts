import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class EmployeeAttendanceService {

  constructor(private _router: Router, private http: HttpClient, private _auth: AuthService) { }


  GetEmployeeAttendance1(
    _attendanceParam: any
  ): Observable<any> {

    return this.http.post<any>(
      `${environment.baseUrl}api/Attendance/GetEmployeeAttendanceData`,
      _attendanceParam
    );
  }

  AddEmployeeAttendance(_attendanceParam: any): Observable<any> {
    return this.http.post<any>(`${environment.baseUrl}api/Attendance/AddEmployeeAttendance`, _attendanceParam)
  }

  GetEmpUnderManager(_attendanceParam: any): Observable<any> {
    return this.http.post<any>(`${environment.baseUrl}api/Attendance/GetEmployeeUnderManager`, _attendanceParam)
  }

  ApproveRejectAttendance(_attendanceParam:any):Observable<any>{
    return this.http.post<any>(`${environment.baseUrl}api/Attendance/ApproveRejectAttendanceByManager`,_attendanceParam)
}
}
