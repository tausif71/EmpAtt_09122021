import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { AuthService } from './auth.service';
import {environment} from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class MasterService {
  httpOptions={};
  constructor(private _auth:AuthService,private http:HttpClient) {
    
   }

   
   GetAllLocation(): Observable<any> {
    // const token=this._auth.getAuthorizationToken();
    // const httpOptions = {
    //   headers: new HttpHeaders({
    //     'Content-Type':  'application/json',
    //     'Authorization': `Bearer ${token}`,
    //   })
    // };
    return this.http.get<any>(`${environment.baseUrl}api/MasterData/GetAllLocation`);
  }
}
