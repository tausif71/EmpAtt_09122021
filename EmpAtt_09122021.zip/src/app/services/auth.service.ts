import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import {environment} from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  redirectUrl: string;
  constructor(private _router:Router,private http:HttpClient) { }

  //AuthenticateUser(body:URLSearchParams){
    AuthenticateUser(body:any){
      return this.http
      //.post<any>(`https://giws.saint-gobain.com/MySpace_MA/token`, body.toString(),options)
      .post<any>(`${environment.baseUrl}token`, body.toString())
      .pipe(
        map((response) => {
          if (response && response.access_token) {
            if (response.hasOwnProperty("access_token")) {
              localStorage.setItem('sgid',response["SGID"]);
              localStorage.setItem("token", response["access_token"]);
              localStorage.setItem("profilepic", response["SGID"]);
              localStorage.setItem('username', response["userName"]);
              localStorage.setItem('designation', response["Designation"]);
              localStorage.setItem('empcount', response["EmpCount"]);
              localStorage.setItem('empemail', response["Email"]);
              this._router.navigate(['/add-attendance']);
            }
          } else if(response.error=='invalid_grant'){
            return response.error;
          }
        })
      );
    }
  /***********
   * if token is still present in localstorage 
   * then that token will pass to other request
   ***********/
   isLoggedIn() {
    if (localStorage.getItem('token')) {
      return true;
    }
    return false;
  }

  /***************
   * this will return logged in userid
   ***************/
  getLoggedInUserid() {
    const userid = localStorage.getItem('sgid');
    if (userid == null) {
      return '';
    }
    return userid;
  }

  
  /***************
   * this will return token string
   ****************/
  getAuthorizationToken() {
    const access_token = localStorage.getItem('token');
    if (access_token == null) {
      return '';
    }
    return access_token;
  }


  /******************
   * This will delete all session or local storag from browser
   * and redirect to login page
   ******************/
  logoutSession() {
    localStorage.removeItem('username');
    localStorage.removeItem('token');
    localStorage.removeItem('profilepic');
    localStorage.removeItem('designation');
    localStorage.removeItem('sgid');
    localStorage.removeItem('empcount');
    localStorage.removeItem('empemail');
    this._router.navigateByUrl('/login');
  }

}
