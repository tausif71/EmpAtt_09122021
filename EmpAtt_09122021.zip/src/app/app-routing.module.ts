import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddAttedanceComponent } from './components/add-attedance/add-attedance.component';
import { LoginComponent } from './components/login/login.component';
import { ViewAttendanceComponent } from './components/view-attendance/view-attendance.component';
import { AuthGuard } from './guards/auth.guard';
import { IncompleteTaskGuardGuard } from './guards/incomplete-task-guard.guard';

const routes: Routes = [
  {
    path:'',
    redirectTo:'/login',
    pathMatch:'full'
  },{
    path: 'login',
    component: LoginComponent,
},
{
  path:'add-attendance',
  canActivate: [AuthGuard],
  //canDeactivate: [IncompleteTaskGuardGuard],
  component:AddAttedanceComponent
},
{
  path:'view-attendance',
  canActivate: [AuthGuard],
  component:ViewAttendanceComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
