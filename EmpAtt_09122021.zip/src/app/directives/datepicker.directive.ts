import { AfterViewInit, Directive, ElementRef, EventEmitter, Input, NgZone, Output } from '@angular/core';
declare var $: any;
@Directive({
  selector: '[appDatepicker]'
})
export class DatepickerDirective implements AfterViewInit {
  mySelectedDate:any;
  @Output() dateEventEmitter=new EventEmitter();
  _myAttendanceObject:any;
   public pickDate(date: any): void {
    this.mySelectedDate=date;
    console.log(date)
    this.dateEventEmitter.emit(date);
}
  constructor(private el: ElementRef, private ngzone: NgZone) { 
    
  }

  ngAfterViewInit() {
    this.ngzone.runOutsideAngular(() => {
      $(this.el.nativeElement).datepicker({
        onSelect: (date)=>{
          this.ngzone.run(()=>{
              this.pickDate(date);
          })
        },
        maxDate: new Date(),
        dateFormat: 'yy-mm-dd'
      });
    })
  }

 
}
